# "Seeds" folder

Data seeds for knex-based databases
