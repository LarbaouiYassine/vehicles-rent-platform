import marked from 'marked'
import _ from 'lodash'

const htmlEscapeToText = function (text) {
  return text.replace(/&#[0-9]*;|&amp;/g, function (escapeCode) {
    if (escapeCode.match(/amp/)) {
      return '&'
    }

    return String.fromCharCode(escapeCode.match(/[0-9]+/))
  })
}

