import _ from 'lodash'
import fs from 'fs'
import moment from 'moment'
import { isPromise } from './is-promise'

export const checkIsFullVirtual = (Model) => {
  // check if model have only calculated fields
  let allCalculated = true
  Model.props.map((prop) => {
    if (!(prop.calculated && prop.calculated === true)) {
      allCalculated = false
    }
  })
  return allCalculated
}

export const processBeforeSaveToStorage = (Model, item, opts) => {
  // console.log(`processBeforeSaveToStorage(${Model.name}, ${JSON.stringify(item)})\n`)
  const aItem = _.merge({}, item)
  opts = opts || { defaults: true }

  // check if all keys are defined in model
  const aKeys = Object.keys(aItem)
  aKeys.map((key) => {
    // copy property to proxy object
    const prop = _.find(Model.props, { name: key })
    if (!prop) {
      throw new Error(`${Model.name}.processBeforeSaveToStorage: property "${key}" is not defined in model`)
    }
  })

  // process all default props if they are not defined in item:
  Model.props.map((prop) => {
    if (opts.defaults && prop.default && (!item[prop.name] || item[prop.name] === null || item[prop.name] === undefined)) {
      if (typeof prop.default === 'function') {
        aItem[prop.name] = prop.default(aItem)
      } else {
        aItem[prop.name] = prop.default
      }
    }
    if (prop.beforeSave && item[prop.name] && (typeof prop.beforeSave === 'function')) {
      // console.log(prop.beforeSave.toString())
      // console.log(aItem)
      aItem[prop.name] = prop.beforeSave(aItem)
    }
    if (prop.type === 'boolean') {
      aItem[prop.name] = item[prop.name] ? 1 : 0
    }
    if (prop.type === 'id') {
      Model.key = prop.name
    }
    if (item[prop.name] && prop.type === 'datetime') {
      aItem[prop.name] = moment.utc(item[prop.name]).toDate()
    }
    if (prop.type === 'enum') {
      // ensure enum values are in range:
      if (!_.find(prop.format, { value: item[prop.name] })) {
        throw Error(`${Model.name}.${prop.name} enum value invalid: not found in enum format definition`)
      }
    }
    if (prop.calculated) {
      delete aItem[prop.name]
    }

    // replace refs array with string representation
    if (prop.type === 'refs') {
      if (!item[prop.name] || item[prop.name] === [] || item[prop.name] === '') {
        aItem[prop.name] = null
      } else if (Array.isArray(item[prop.name])) {
        aItem[prop.name] = item[prop.name].join(',')
      }
    }
  })
  // console.log(`processBeforeSaveToStorage result:\n${JSON.stringify(aItem)}`)
  return aItem
}

export const processAfterLoadFromStorageAsync = (Model, item) => {
  if (!item) {
    return Promise.resolve(item)
  }
  const aItem = processAfterLoadFromStorage(Model, item)
  const values = []
  const props = []
  Model.props.map((prop) => {
    if (prop.calculated && aItem[prop.name] && isPromise(aItem[prop.name])) {
      props.push(prop)
      values.push(aItem[prop.name])
    }
  })
  return Promise.all(values)
    .then((_props) => {
      _props.map((_prop, index) => {
        aItem[props[index].name] = _prop
      })
      return aItem
    }, (reason) => {
      throw new Error(reason)
    })
    .catch((e) => { throw e })
}

