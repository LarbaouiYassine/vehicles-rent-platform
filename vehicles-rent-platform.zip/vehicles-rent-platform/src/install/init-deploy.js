export const deployVEHICULESRent = 'ba59f20d-7d3b-462c-9e6e-00f24b8bdd7e'
export const deployBetaVEHICULESRent = 'a26b55fa-d7e3-4e1f-83a0-d14993ed75e0'

export const InitDeploy = (app) => () => {
  return Promise.resolve()
    .then(() => app.exModular.models.DeployProject.count())
    .then((count) => {
      if (!count || count === 0) {
        return app.exModular.models.DeployProject.create({
          id: deployVEHICULESRent,
          name: 'vehicles-rent-site',
          fullName: 'vehicles-rent/vehicles-rent-site',
          script: '/home/deksden/_apps/vehicles_rent.sh',
          scriptTimeout: 180000,
          branch: 'master',
          site: 'vehicles.rent',
          siteConfigPath: '/etc/nginx/sites-available/vehicles.rent'
        })
          .then(() => app.exModular.models.DeployProject.create({
            id: deployBetaVEHICULESRent,
            name: 'vehicles-rent-site',
            fullName: 'vehicles-rent/vehicles-rent-site',
            script: '/home/deksden/_apps/vehicles_rent.sh',
            scriptTimeout: 180000,
            branch: 'beta',
            site: 'beta.vehicles.rent',
            siteConfigPath: '/etc/nginx/sites-available/beta.vehicles.rent'
          }))
      }
    })
    .catch((e) => {
      throw e
    })
}
