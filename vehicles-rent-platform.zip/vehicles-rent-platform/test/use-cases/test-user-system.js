/* eslint-env mocha */
import { describe, it, before, beforeEach, after } from 'mocha'
import supertest from 'supertest'
import chai, { expect } from 'chai'
import dirtyChai from 'dirty-chai'
import env from 'dotenv-safe'
import _ from 'lodash'

import App from '../../src/packages/app-builder'

import {
  UserAdmin,
  UserFirst, UserSecond, expected,
  // UserFirst,
  // userList,
  loginAs, signupUser,
  meGroups,
  userGroupAdd,
  userGroupUsersAdd,
  permissionUserGroupCreate,
  noteAdd, noteSave, userGroupUsersList, userGroupUsersRemove, meGrantAdd, noteList, meAccess
  // userDelete,
  // userSave
} from '../client/client-api'
import * as ACCESS from '../../src/packages/const-access'
import { ExtTest } from '../../src/test/test'

/**

*/

chai.use(dirtyChai)

