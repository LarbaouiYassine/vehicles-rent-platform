# Vehicles.rent Server

Implemented features:

* exModular based app
* GitHub webhook controller extention
* self-manage of own codebase with app


